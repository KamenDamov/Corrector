import gui.Corrector;

public class Main {
    public static void main(String[] args) {
        //Declaring GUI
        gui.GUI g = new gui.GUI();
    }
}
